import { router } from '../router';

export function createLoginPage(): HTMLElement {
  const container = document.createElement('div');
  container.className = 'auth-page';
  
  container.innerHTML = `
    <div class="auth-container">
      <div class="auth-card">
        <div class="auth-header">
          <h2>Fazer Login</h2>
          <p>Entre na sua conta para continuar</p>
        </div>
        
        <form id="login-form" class="auth-form">
          <div class="form-group">
            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" required placeholder="seu@email.com">
          </div>
          
          <div class="form-group">
            <label for="password">Senha</label>
            <input type="password" id="password" name="password" required placeholder="••••••••">
          </div>
          
          <div class="form-options">
            <label class="checkbox-label">
              <input type="checkbox" id="remember">
              <span class="checkmark"></span>
              Lembrar de mim
            </label>
            <a href="#" class="forgot-link">Esqueceu a senha?</a>
          </div>
          
          <button type="submit" class="btn btn-primary btn-full">Entrar</button>
        </form>
        
        <div class="auth-footer">
          <p>Não tem uma conta? 
            <button id="go-register" class="link-btn">Cadastre-se</button>
          </p>
        </div>
      </div>
      
      <button id="back-home" class="back-btn">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
        </svg>
        Voltar
      </button>
    </div>
  `;

  // Event listeners
  const form = container.querySelector('#login-form') as HTMLFormElement;
  const goRegisterBtn = container.querySelector('#go-register') as HTMLButtonElement;
  const backBtn = container.querySelector('#back-home') as HTMLButtonElement;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;
    
    // Simulação de login - redireciona para dashboard
    console.log('Login:', { email, password });
    router.navigate('dashboard');
  });

  goRegisterBtn.addEventListener('click', () => router.navigate('register'));
  backBtn.addEventListener('click', () => router.navigate('home'));

  return container;
}