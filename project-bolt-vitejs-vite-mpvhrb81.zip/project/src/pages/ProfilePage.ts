import { router } from '../router';

export function createProfilePage(): HTMLElement {
  const container = document.createElement('div');
  container.className = 'app-page';
  
  container.innerHTML = `
    <nav class="navbar">
      <div class="nav-container">
        <div class="nav-brand">
          <h2>Meu App</h2>
        </div>
        
        <div class="nav-menu">
          <button class="nav-item" data-route="dashboard">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
            </svg>
            Dashboard
          </button>
          
          <button class="nav-item active" data-route="profile">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7-7h14a7 7 0 00-7-7z"></path>
            </svg>
            Perfil
          </button>
          
          <button class="nav-item" data-route="messages">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
            </svg>
            Mensagens
          </button>
          
          <button class="nav-item" data-route="search">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
            </svg>
            Busca
          </button>
          
          <button class="nav-item" data-route="orders">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
            </svg>
            Pedidos
          </button>
        </div>
        
        <div class="nav-actions">
          <button class="logout-btn" id="logout-btn">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
            </svg>
            Sair
          </button>
        </div>
      </div>
    </nav>
    
    <main class="main-content">
      <div class="page-container">
        <div class="page-header">
          <h1>Meu Perfil</h1>
          <p>Gerencie suas informações pessoais</p>
        </div>
        
        <div class="profile-content">
          <div class="profile-card">
            <div class="profile-avatar">
              <div class="avatar-placeholder">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                </svg>
              </div>
              <button class="change-avatar-btn">Alterar Foto</button>
            </div>
            
            <form class="profile-form">
              <div class="form-row">
                <div class="form-group">
                  <label for="firstName">Nome</label>
                  <input type="text" id="firstName" value="João" placeholder="Seu nome">
                </div>
                <div class="form-group">
                  <label for="lastName">Sobrenome</label>
                  <input type="text" id="lastName" value="Silva" placeholder="Seu sobrenome">
                </div>
              </div>
              
              <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" id="email" value="joao@email.com" placeholder="seu@email.com">
              </div>
              
              <div class="form-group">
                <label for="phone">Telefone</label>
                <input type="tel" id="phone" value="(11) 99999-9999" placeholder="(11) 99999-9999">
              </div>
              
              <div class="form-group">
                <label for="bio">Biografia</label>
                <textarea id="bio" rows="4" placeholder="Conte um pouco sobre você...">Desenvolvedor apaixonado por tecnologia e inovação.</textarea>
              </div>
              
              <div class="form-actions">
                <button type="button" class="btn btn-secondary">Cancelar</button>
                <button type="submit" class="btn btn-primary">Salvar Alterações</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </main>
  `;

  // Event listeners
  const navItems = container.querySelectorAll('.nav-item');
  const logoutBtn = container.querySelector('#logout-btn') as HTMLButtonElement;
  const profileForm = container.querySelector('.profile-form') as HTMLFormElement;

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const route = item.getAttribute('data-route') as any;
      if (route) {
        router.navigate(route);
      }
    });
  });

  logoutBtn.addEventListener('click', () => {
    router.navigate('home');
  });

  profileForm.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Perfil atualizado com sucesso!');
  });

  return container;
}