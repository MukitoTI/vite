import { router } from '../router';

export function createRegisterPage(): HTMLElement {
  const container = document.createElement('div');
  container.className = 'auth-page';
  
  container.innerHTML = `
    <div class="auth-container">
      <div class="auth-card">
        <div class="auth-header">
          <h2>Criar Conta</h2>
          <p>Cadastre-se para começar a usar</p>
        </div>
        
        <form id="register-form" class="auth-form">
          <div class="form-group">
            <label for="name">Nome Completo</label>
            <input type="text" id="name" name="name" required placeholder="Seu nome completo">
          </div>
          
          <div class="form-group">
            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" required placeholder="seu@email.com">
          </div>
          
          <div class="form-group">
            <label for="password">Senha</label>
            <input type="password" id="password" name="password" required placeholder="••••••••">
          </div>
          
          <div class="form-group">
            <label for="confirm-password">Confirmar Senha</label>
            <input type="password" id="confirm-password" name="confirmPassword" required placeholder="••••••••">
          </div>
          
          <div class="form-options">
            <label class="checkbox-label">
              <input type="checkbox" id="terms" required>
              <span class="checkmark"></span>
              Aceito os <a href="#" class="link">termos de uso</a>
            </label>
          </div>
          
          <button type="submit" class="btn btn-primary btn-full">Criar Conta</button>
        </form>
        
        <div class="auth-footer">
          <p>Já tem uma conta? 
            <button id="go-login" class="link-btn">Faça login</button>
          </p>
        </div>
      </div>
      
      <button id="back-home" class="back-btn">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
        </svg>
        Voltar
      </button>
    </div>
  `;

  // Event listeners
  const form = container.querySelector('#register-form') as HTMLFormElement;
  const goLoginBtn = container.querySelector('#go-login') as HTMLButtonElement;
  const backBtn = container.querySelector('#back-home') as HTMLButtonElement;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    const name = formData.get('name') as string;
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;
    const confirmPassword = formData.get('confirmPassword') as string;
    
    if (password !== confirmPassword) {
      alert('As senhas não coincidem!');
      return;
    }
    
    // Simulação de cadastro - redireciona para dashboard
    console.log('Register:', { name, email, password });
    router.navigate('dashboard');
  });

  goLoginBtn.addEventListener('click', () => router.navigate('login'));
  backBtn.addEventListener('click', () => router.navigate('home'));

  return container;
}