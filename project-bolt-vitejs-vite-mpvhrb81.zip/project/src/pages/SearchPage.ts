import { router } from '../router';

export function createSearchPage(): HTMLElement {
  const container = document.createElement('div');
  container.className = 'app-page';
  
  container.innerHTML = `
    <nav class="navbar">
      <div class="nav-container">
        <div class="nav-brand">
          <h2>Meu App</h2>
        </div>
        
        <div class="nav-menu">
          <button class="nav-item" data-route="dashboard">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
            </svg>
            Dashboard
          </button>
          
          <button class="nav-item" data-route="profile">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7-7h14a7 7 0 00-7-7z"></path>
            </svg>
            Perfil
          </button>
          
          <button class="nav-item" data-route="messages">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
            </svg>
            Mensagens
          </button>
          
          <button class="nav-item active" data-route="search">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
            </svg>
            Busca
          </button>
          
          <button class="nav-item" data-route="orders">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
            </svg>
            Pedidos
          </button>
        </div>
        
        <div class="nav-actions">
          <button class="logout-btn" id="logout-btn">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
            </svg>
            Sair
          </button>
        </div>
      </div>
    </nav>
    
    <main class="main-content">
      <div class="page-container">
        <div class="search-header">
          <h1>Busca</h1>
          <p>Encontre o que você precisa</p>
        </div>
        
        <div class="search-content">
          <div class="search-bar">
            <div class="search-input-container">
              <svg class="search-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
              </svg>
              <input type="text" id="search-input" placeholder="Digite sua busca...">
              <button class="search-btn">Buscar</button>
            </div>
          </div>
          
          <div class="search-filters">
            <h3>Filtros</h3>
            <div class="filter-group">
              <label class="filter-label">
                <input type="checkbox" checked>
                <span>Todos</span>
              </label>
              <label class="filter-label">
                <input type="checkbox">
                <span>Usuários</span>
              </label>
              <label class="filter-label">
                <input type="checkbox">
                <span>Produtos</span>
              </label>
              <label class="filter-label">
                <input type="checkbox">
                <span>Documentos</span>
              </label>
            </div>
          </div>
          
          <div class="search-results">
            <div class="results-header">
              <h3>Resultados da busca</h3>
              <span class="results-count">12 resultados encontrados</span>
            </div>
            
            <div class="results-list">
              <div class="result-item">
                <div class="result-icon">
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                  </svg>
                </div>
                <div class="result-content">
                  <h4>João Silva</h4>
                  <p>Desenvolvedor Frontend - São Paulo, SP</p>
                  <span class="result-type">Usuário</span>
                </div>
              </div>
              
              <div class="result-item">
                <div class="result-icon">
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                  </svg>
                </div>
                <div class="result-content">
                  <h4>Sistema de Gestão</h4>
                  <p>Plataforma completa para gerenciamento empresarial</p>
                  <span class="result-type">Produto</span>
                </div>
              </div>
              
              <div class="result-item">
                <div class="result-icon">
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                  </svg>
                </div>
                <div class="result-content">
                  <h4>Manual do Usuário</h4>
                  <p>Guia completo de utilização da plataforma</p>
                  <span class="result-type">Documento</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  `;

  // Event listeners
  const navItems = container.querySelectorAll('.nav-item');
  const logoutBtn = container.querySelector('#logout-btn') as HTMLButtonElement;
  const searchBtn = container.querySelector('.search-btn') as HTMLButtonElement;
  const searchInput = container.querySelector('#search-input') as HTMLInputElement;

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const route = item.getAttribute('data-route') as any;
      if (route) {
        router.navigate(route);
      }
    });
  });

  logoutBtn.addEventListener('click', () => {
    router.navigate('home');
  });

  searchBtn.addEventListener('click', () => {
    const query = searchInput.value;
    if (query.trim()) {
      alert(`Buscando por: ${query}`);
    }
  });

  searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      searchBtn.click();
    }
  });

  return container;
}