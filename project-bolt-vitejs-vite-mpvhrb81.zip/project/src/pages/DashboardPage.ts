import { router } from '../router';

export function createDashboardPage(): HTMLElement {
  const container = document.createElement('div');
  container.className = 'dashboard-page';
  
  container.innerHTML = `
    <nav class="navbar">
      <div class="nav-container">
        <div class="nav-brand">
          <h2>Meu App</h2>
        </div>
        
        <div class="nav-menu">
          <button class="nav-item active" data-route="dashboard">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5a2 2 0 012-2h4a2 2 0 012 2v6H8V5z"></path>
            </svg>
            Dashboard
          </button>
          
          <button class="nav-item" data-route="profile">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
            </svg>
            Perfil
          </button>
          
          <button class="nav-item" data-route="messages">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
            </svg>
            Mensagens
          </button>
          
          <button class="nav-item" data-route="search">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
            </svg>
            Busca
          </button>
          
          <button class="nav-item" data-route="orders">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
            </svg>
            Pedidos
          </button>
        </div>
        
        <div class="nav-actions">
          <button class="logout-btn" id="logout-btn">
            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
            </svg>
            Sair
          </button>
        </div>
      </div>
    </nav>
    
    <main class="main-content">
      <div class="dashboard-container">
        <div class="dashboard-header">
          <h1>Bem-vindo ao Dashboard</h1>
          <p>Gerencie suas atividades e informações</p>
        </div>
        
        <div class="dashboard-grid">
          <div class="dashboard-card">
            <div class="card-icon profile-icon">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
              </svg>
            </div>
            <h3>Perfil</h3>
            <p>Gerencie suas informações pessoais</p>
            <button class="card-btn" data-route="profile">Acessar</button>
          </div>
          
          <div class="dashboard-card">
            <div class="card-icon messages-icon">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
              </svg>
            </div>
            <h3>Mensagens</h3>
            <p>Veja suas conversas e notificações</p>
            <button class="card-btn" data-route="messages">Acessar</button>
          </div>
          
          <div class="dashboard-card">
            <div class="card-icon search-icon">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
              </svg>
            </div>
            <h3>Busca</h3>
            <p>Encontre o que você precisa</p>
            <button class="card-btn" data-route="search">Acessar</button>
          </div>
          
          <div class="dashboard-card">
            <div class="card-icon orders-icon">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
              </svg>
            </div>
            <h3>Pedidos</h3>
            <p>Gerencie seus pedidos e cadastros</p>
            <button class="card-btn" data-route="orders">Acessar</button>
          </div>
        </div>
      </div>
    </main>
  `;

  // Event listeners
  const navItems = container.querySelectorAll('.nav-item');
  const cardBtns = container.querySelectorAll('.card-btn');
  const logoutBtn = container.querySelector('#logout-btn') as HTMLButtonElement;

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const route = item.getAttribute('data-route') as any;
      if (route) {
        router.navigate(route);
      }
    });
  });

  cardBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const route = btn.getAttribute('data-route') as any;
      if (route) {
        router.navigate(route);
      }
    });
  });

  logoutBtn.addEventListener('click', () => {
    router.navigate('home');
  });

  return container;
}