import { router } from '../router';

export function createHomePage(): HTMLElement {
  const container = document.createElement('div');
  container.className = 'home-page';
  
  container.innerHTML = `
    <div class="hero-section">
      <div class="hero-content">
        <h1 class="hero-title">Bem-vindo ao nosso App</h1>
        <p class="hero-subtitle">Faça login ou cadastre-se para começar</p>
        
        <div class="hero-buttons">
          <button id="login-btn" class="btn btn-primary">
            <svg class="btn-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"></path>
            </svg>
            Fazer Login
          </button>
          
          <button id="register-btn" class="btn btn-secondary">
            <svg class="btn-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"></path>
            </svg>
            Criar Conta
          </button>
        </div>
      </div>
      
      <div class="hero-image">
        <div class="floating-card">
          <div class="card-content">
            <div class="card-icon">🚀</div>
            <h3>Comece Agora</h3>
            <p>Junte-se a milhares de usuários</p>
          </div>
        </div>
      </div>
    </div>
  `;

  // Event listeners
  const loginBtn = container.querySelector('#login-btn') as HTMLButtonElement;
  const registerBtn = container.querySelector('#register-btn') as HTMLButtonElement;

  loginBtn.addEventListener('click', () => router.navigate('login'));
  registerBtn.addEventListener('click', () => router.navigate('register'));

  return container;
}