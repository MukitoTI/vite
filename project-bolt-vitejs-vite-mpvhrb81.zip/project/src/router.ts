export type Route = 'home' | 'login' | 'register' | 'dashboard' | 'profile' | 'messages' | 'search' | 'orders';

class Router {
  private currentRoute: Route = 'home';
  private listeners: Array<(route: Route) => void> = [];

  getCurrentRoute(): Route {
    return this.currentRoute;
  }

  navigate(route: Route): void {
    this.currentRoute = route;
    this.notifyListeners();
  }

  onRouteChange(callback: (route: Route) => void): void {
    this.listeners.push(callback);
  }

  private notifyListeners(): void {
    this.listeners.forEach(callback => callback(this.currentRoute));
  }
}

export const router = new Router();