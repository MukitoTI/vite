import './style.css';
import { router, Route } from './router';
import { createHomePage } from './pages/HomePage';
import { createLoginPage } from './pages/LoginPage';
import { createRegisterPage } from './pages/RegisterPage';
import { createDashboardPage } from './pages/DashboardPage';
import { createProfilePage } from './pages/ProfilePage';
import { createMessagesPage } from './pages/MessagesPage';
import { createSearchPage } from './pages/SearchPage';
import { createOrdersPage } from './pages/OrdersPage';

class App {
  private appElement: HTMLElement;

  constructor() {
    this.appElement = document.querySelector<HTMLDivElement>('#app')!;
    this.init();
  }

  private init(): void {
    router.onRouteChange((route: Route) => {
      this.render(route);
    });
    
    // Render initial page
    this.render(router.getCurrentRoute());
  }

  private render(route: Route): void {
    // Clear current content
    this.appElement.innerHTML = '';
    
    let pageElement: HTMLElement;
    
    switch (route) {
      case 'home':
        pageElement = createHomePage();
        break;
      case 'login':
        pageElement = createLoginPage();
        break;
      case 'register':
        pageElement = createRegisterPage();
        break;
      case 'dashboard':
        pageElement = createDashboardPage();
        break;
      case 'profile':
        pageElement = createProfilePage();
        break;
      case 'messages':
        pageElement = createMessagesPage();
        break;
      case 'search':
        pageElement = createSearchPage();
        break;
      case 'orders':
        pageElement = createOrdersPage();
        break;
      default:
        pageElement = createHomePage();
    }
    
    this.appElement.appendChild(pageElement);
  }
}

// Initialize the app
new App();